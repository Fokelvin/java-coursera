public class Principal {
	public static void main(String[] args) {
		Paciente p1 = new Paciente(72, 1.75);
		p1.calcularIMC();
		p1.diagnostico();
		p1.imprimir();
		
		Paciente p2 = new Paciente(80, 1.60);
		p2.calcularIMC();
		p2.diagnostico();
		p2.imprimir();
		
		Paciente p3 = new Paciente(110, 1.98);
		p3.calcularIMC();
		p3.diagnostico();
		p3.imprimir();
	}
}
